package game;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import static java.awt.image.ImageObserver.ABORT;
import javax.swing.JOptionPane;

public class Ball {
	private static final int DIAMETER = 30;
	
	int x = 0;
	int y = 0;
	int xa = 2;
	int ya = 2;
	private Game game;

	public Ball(Game game) {
		this.game = game;
	}
        

    Ball(Ball ball) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

	void move() {
		//boolean changeDirection = true;
		if (x + xa < 0)
			xa = 2;
		if (x + xa > game.getWidth() - DIAMETER)
			xa = -2;
		if (y + ya < 0)
			ya = ya = game.speed;
		if (y + ya > game.getHeight() - DIAMETER)
			game.gameOver();
           // boolean changeDirection = false;
		if (getScore()){
			ya = -game.speed;
			//y = game.racquet.getTopY() - DIAMETER;
			game.speed++;
		} 
                 
			//Sound.BALL.play();
		x = x + xa;
		y = y + ya;
	}

	private boolean getScore() {
		return game.racquet.getBounds().intersects(getBounds());
	}

	public void paint(Graphics2D g) {
		g.fillOval(x, y, DIAMETER, DIAMETER);
	}

	public Rectangle getBounds() {
		return new Rectangle(x, y, DIAMETER, DIAMETER);
	}
}